import { Component, OnInit } from '@angular/core';
import { Certificate } from '../certificate';

@Component({
  selector: 'app-certificates',
  templateUrl: './certificates.component.html',
  styleUrls: ['./certificates.component.css']
})
export class CertificatesComponent implements OnInit {
  certificate: Certificate = {
    id: 1,
    name: 'Web Dev Techniques'
  };

  constructor() { }

  ngOnInit() {
  }

}
