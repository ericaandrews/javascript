export class Certificate {
    id: number;
    name: string;
  }