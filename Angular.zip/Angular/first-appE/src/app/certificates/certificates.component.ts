import { Component, OnInit } from '@angular/core';
import { Certificate } from '../certificate';
import { Certificates } from '../list-certificates';

@Component({
  selector: 'app-certificates',
  templateUrl: './certificates.component.html',
  styleUrls: ['./certificates.component.css']
})
export class CertificatesComponent implements OnInit {
  certificates = Certificates;

  selectedCertificate: Certificate;

  constructor() { }

  ngOnInit() {
  }

  onSelect(certificate: Certificate): void {
    this.selectedCertificate = certificate;
  }

}
