import { Certificate } from './certificate';

export const Certificates: Certificate[] = [
  { id: 10, name: 'Web Dev Techniques' },
  { id: 11, name: 'JavaScript Specialist' },
  { id: 12, name: 'Mobile Web Development' },
  { id: 13, name: 'Advanced Web Dev' },
];