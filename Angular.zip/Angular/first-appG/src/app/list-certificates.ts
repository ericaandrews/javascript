import { Certificate } from './certificate';

export const Certificates: Certificate[] = [
  { id: 10, name: 'Web Dev Techniques', units: 12 },
  { id: 11, name: 'JavaScript Specialist', units: 15 },
  { id: 12, name: 'Mobile Web Development', units: 12 },
  { id: 13, name: 'Advanced Web Dev', units: 15 },
];