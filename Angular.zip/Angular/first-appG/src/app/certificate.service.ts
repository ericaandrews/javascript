import { Injectable } from '@angular/core';
import { Certificate } from './certificate';
import { Certificates } from './list-certificates';

@Injectable({
  providedIn: 'root'
})
export class CertificateService {

  constructor() { }

  getCertificates(): Certificate[] {
    return Certificates;
 }
}
