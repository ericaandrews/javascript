import { Component, OnInit, Input } from '@angular/core';
import { Certificate } from '../certificate';

@Component({
  selector: 'app-certificate-detail',
  templateUrl: './certificate-detail.component.html',
  styleUrls: ['./certificate-detail.component.css']
})
export class CertificateDetailComponent implements OnInit {
  @Input() certificate: Certificate;
  
  constructor() { }

  ngOnInit() {
  }

  setColor() {
    return this.certificate.units > 12 ? 'orange' : 'lightgreen';
  }
}
