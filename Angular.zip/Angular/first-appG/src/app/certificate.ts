export class Certificate {
    id: number;
    name: string;
    units: number;
  }