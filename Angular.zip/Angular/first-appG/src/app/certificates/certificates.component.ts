import { Component, OnInit } from '@angular/core';
import { Certificate } from '../certificate';
/* import { Certificates } from '../list-certificates'; */
import { CertificateService } from '../certificate.service';

@Component({
  selector: 'app-certificates',
  templateUrl: './certificates.component.html',
  styleUrls: ['./certificates.component.css']
})
export class CertificatesComponent implements OnInit {
  certificates: Certificate[];

  selectedCertificate: Certificate;

  constructor(private certificateService: CertificateService) { }

  ngOnInit() {
    this.getCertificates();
  }

  onSelect(certificate: Certificate): void {
    this.selectedCertificate = certificate;
  }

  getCertificates(): void {
    this.certificates = this.certificateService.getCertificates();
  }

}
